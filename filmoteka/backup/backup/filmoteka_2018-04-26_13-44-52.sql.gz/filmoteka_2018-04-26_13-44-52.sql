#SXD20|20011|50638|50538|2018.04.26 13:44:52|filmoteka|utf8|1|6|
#TA films`6`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  `description` text NOT NULL,
  `photo` char(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(23,'\"Elizeum\" рай но не на земле','Fantasi',2016,'','21519165.jpg'),
(25,'Tакси 25','комедия',2012,'','48202209.jpg'),
(26,'thor','Фантастика',2018,'It is the Hela of Blanchett, when there\'s a link in the line-up. The scenes of Hela, although essential to the storyline, feel an undesirable distraction such as Mjolnir, aching to get a return. Meanwhile although its clowning is, the film feels overly glib. More heavy beats, such as also the reduction of a personality and slaughter, are swept away. But in a movie that manages to package fire demons, a dragon, a wolf, zombies, a goddess of death and the Sorcerer Supreme, it is difficult to feel too. Attempt to fit it but roll with this and you will discover a accession to the Marvel Universe, but among the most enjoyable comedies of the year.\r\n\r\n','23482971.jpg'),
(27,'Fast','Фантастика',2008,'','49666137.jpg'),
(28,'Police Academy','комедия',1998,'','98571777.jpg'),
(29,'Fast','Fantasi',2012,'','20022277.jpg')	;
