#SXD20|20011|50638|50538|2018.04.06 06:30:51|filmoteka|utf8|1|4|
#TA films`4`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(1,'Такси 2','комедия',2000),
(2,'Облачный атлас','драма',2012),
(5,'Fast & Furies','action',2012),
(9,'Fast','action',2012),
(10,'Police Academy','комедия',1998)	;
